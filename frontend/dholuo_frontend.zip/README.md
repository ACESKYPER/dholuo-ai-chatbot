Dholuo AI Chatbot — Frontend Starter (ESM, Vite + React + Tailwind)
----
This is a ready-to-run frontend starter for the Dholuo AI Chatbot.
Instructions:
1. cd frontend
2. npm install
3. npm run dev
4. Open http://localhost:5173
The frontend expects a backend at http://127.0.0.1:8000/ai returning JSON { "response": "..."}
